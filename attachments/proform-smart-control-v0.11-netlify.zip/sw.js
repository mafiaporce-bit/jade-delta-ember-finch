// Service worker: keeps the app shell available offline.
// Bluetooth itself always needs the page open and the treadmill in range.
const CACHE = 'psc-9c40bf6fbb';
// Large files fetched once and kept across app updates (the 3D person).
const ASSETS = 'pscassets-1';
const FILES = ["/","/assets/app-168aeac10c.css","/assets/app-4c4bd27a17.js","/icons/icon-192.png","/icons/icon-512.png","/icons/icon.svg","/icons/maskable-512.png","/manifest.webmanifest","/virtual/park/poster.jpg","/virtual/park/walk-0.webp","/virtual/park/walk-1.webp","/virtual/park/walk-2.webp","/virtual/park/walk-3.webp","/virtual/park/walk-4.webp","/virtual/park/walk-5.webp","/virtual-park/app.js","/virtual-park/assets/tex/CREDITS.txt","/virtual-park/assets/tex/asphalt.jpg","/virtual-park/assets/tex/asphalt_n.jpg","/virtual-park/assets/tex/bark.jpg","/virtual-park/assets/tex/bark_n.jpg","/virtual-park/assets/tex/bloom.webp","/virtual-park/assets/tex/env.jpg","/virtual-park/assets/tex/fir.webp","/virtual-park/assets/tex/firbark.jpg","/virtual-park/assets/tex/grass.jpg","/virtual-park/assets/tex/kerb.jpg","/virtual-park/assets/tex/leaves.webp","/virtual-park/assets/tex/mulch.jpg","/virtual-park/assets/tex/rock.jpg","/virtual-park/assets/tex/rock_n.jpg","/virtual-park/assets/tex/sky.jpg","/virtual-park/assets/tex/water_n.jpg","/virtual-park/bridge.js","/virtual-park/","/virtual-park/photo.js","/virtual-park/props.js","/virtual-park/scenery.js","/virtual-park/styles.css","/virtual-park/vendor/LICENSE-three.txt","/virtual-park/vendor/addons/loaders/GLTFLoader.js","/virtual-park/vendor/addons/utils/BufferGeometryUtils.js","/virtual-park/vendor/three.core.min.js","/virtual-park/vendor/three.module.min.js"];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('psc-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // 3D engine, voice model, CDN: straight to network
  if (req.mode === 'navigate') {
    // Pages (the app, and the 3D park inside it): network first, then the saved copy.
    event.respondWith(
      fetch(req).catch(() => caches.match(req, { ignoreSearch: true }).then((hit) => hit || caches.match('/'))),
    );
    return;
  }
  if (url.pathname.endsWith('.glb')) {
    event.respondWith(
      caches.open(ASSETS).then((cache) =>
        cache.match(req).then(
          (hit) =>
            hit ||
            fetch(req).then((res) => {
              if (res.ok && res.status === 200) cache.put(req, res.clone());
              return res;
            }),
        ),
      ),
    );
    return;
  }
  event.respondWith(caches.match(req).then((hit) => hit || fetch(req)));
});
